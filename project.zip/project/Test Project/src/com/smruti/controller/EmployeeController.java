package com.arun.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.arun.bean.EmployeeBean;
import com.arun.dao.EmployeeDAOImpl;

@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//general settings
		response.setContentType("text/html");
		PrintWriter writer=response.getWriter();
		HttpSession session=request.getSession();
		//create employee dao object
		EmployeeDAOImpl dao=new EmployeeDAOImpl();
		try{
			//get pressed button
			String pressed_button=request.getParameter("button");
			
			if(pressed_button.equals("insert")){
				//get parameter value
				int employee_id=Integer.parseInt(request.getParameter("employee_id"));
				String employee_name=request.getParameter("employee_name");
				String employee_addrss=request.getParameter("employee_address");
				String employee_sal=request.getParameter("employee_sal");
				int deptno=Integer.parseInt(request.getParameter("deptno"));
				//create bean object
				EmployeeBean bean=new EmployeeBean();
				bean.setEmployee_id(employee_id);
				bean.setEmployee_name(employee_name);
				bean.setEmployee_address(employee_addrss);
				bean.setEmployee_sal(employee_sal);
				bean.setDeptno(deptno);
				
				//now insert bean object
				int count=dao.insertEmployee(bean);
				if(count>0){
					session.setAttribute("id", employee_id);
					session.setAttribute("result","i_successful");
					response.sendRedirect("employee_view.jsp");
				}else{
					session.setAttribute("id", employee_id);
					session.setAttribute("result","i_unsuccessful");
					response.sendRedirect("employee_view.jsp");
				}
			}else if(pressed_button.equals("update")){
				//get parameter value
				int employee_id=Integer.parseInt(request.getParameter("employee_id"));
				String employee_name=request.getParameter("employee_name");
				String employee_addrss=request.getParameter("employee_address");
				String employee_sal=request.getParameter("employee_sal");
				int deptno=Integer.parseInt(request.getParameter("deptno"));
				//create bean object
				EmployeeBean bean=new EmployeeBean();
				bean.setEmployee_id(employee_id);
				bean.setEmployee_name(employee_name);
				bean.setEmployee_address(employee_addrss);
				bean.setEmployee_sal(employee_sal);
				bean.setDeptno(deptno);
				
				//now update bean object
				int count=dao.updateEmployee(bean);
				if(count>0){
					session.setAttribute("id", employee_id);
					session.setAttribute("result","u_successful");
					response.sendRedirect("employee_view.jsp");
				}else{
					session.setAttribute("id", employee_id);
					session.setAttribute("result","u_unsuccessful");
					response.sendRedirect("employee_view.jsp");
				}
			}else if(pressed_button.equals("delete")){
				//get request parameter value
				int employee_id=Integer.parseInt(request.getParameter("employee_id"));
				int count=dao.deleteEmployee(employee_id);
				if(count>0){
					session.setAttribute("id", employee_id);
					session.setAttribute("result","d_successful");
					response.sendRedirect("employee_view.jsp");
				}else{
					session.setAttribute("result","d_unsuccessful");
					response.sendRedirect("employee_view.jsp");
				}
			}else if(pressed_button.equals("check")){
				//get request parameter value
				int employee_id=Integer.parseInt(request.getParameter("employee_id"));
				//now check thevalue
				boolean isAvailable=dao.checkAvialableOfEmployeeId(employee_id);
				if(isAvailable==true){
					writer.println("available");
				}
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
