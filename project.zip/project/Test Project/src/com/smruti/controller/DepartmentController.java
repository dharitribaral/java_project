package com.arun.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.arun.bean.DepartmentBean;
import com.arun.dao.DepartmentDAOImpl;
import com.arun.dao.EmployeeDAOImpl;


@WebServlet("/DepartmentController")
public class DepartmentController extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//general settings
				response.setContentType("text/html");
				PrintWriter writer=response.getWriter();
				HttpSession session=request.getSession();
				//create department dao object
				DepartmentDAOImpl dao=new DepartmentDAOImpl();
				try{
					//get pressed button
					String pressed_button=request.getParameter("button");
					
					
					
					//this place for insert of record
					if(pressed_button.equals("insert")){
						//get request parameter value
						int deptno=Integer.parseInt(request.getParameter("deptno"));
						String deptname=request.getParameter("deptname");
						String location=request.getParameter("location");
						//create DepartmentBean object
						DepartmentBean bean=new DepartmentBean();
						bean.setDeptno(deptno);
						bean.setDeptname(deptname);
						bean.setLocation(location);
						//now insert department
						int count=dao.insertDepartment(bean);
						if(count>0){
							session.setAttribute("id", deptno);
							session.setAttribute("result", "i_successful");
							response.sendRedirect("dept_view.jsp");
						}else{
							session.setAttribute("id", deptno);
							session.setAttribute("result", "i_unsuccessful");
							response.sendRedirect("dept_view.jsp");
						}
					}
					
					
					
					//this place is for update record
					else if(pressed_button.equals("update")){
						//get request parameter value
						int deptno=Integer.parseInt(request.getParameter("deptno"));
						String deptname=request.getParameter("deptname");
						String location=request.getParameter("location");
						//create DepartmentBean object
						DepartmentBean bean=new DepartmentBean();
						bean.setDeptno(deptno);
						bean.setDeptname(deptname);
						bean.setLocation(location);
						//now insert department
						int count=dao.updateDepartment(bean);
						if(count>0){
							session.setAttribute("id", deptno);
							session.setAttribute("result", "u_successful");
							response.sendRedirect("dept_view.jsp");
						}else{
							session.setAttribute("id", deptno);
							session.setAttribute("result", "u_unsuccessful");
							response.sendRedirect("dept_view.jsp");
						}
					}
					
					//this place for delete of the record
					
					else if(pressed_button.equals("delete")){
						//get request parameter value
						int deptno=Integer.parseInt(request.getParameter("deptno"));
						int count=dao.deleteDepartment(deptno);
						if(count>0){
							session.setAttribute("id", deptno);
							session.setAttribute("result", "d_successful");
							response.sendRedirect("dept_view.jsp");
						}else{
							session.setAttribute("id", deptno);
							session.setAttribute("result", "d	_unsuccessful");
							response.sendRedirect("dept_view.jsp");
						}
					}
					
				}catch(Exception e){
					e.printStackTrace();
				}
	}

}
