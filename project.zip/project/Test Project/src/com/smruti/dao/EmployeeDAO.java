package com.arun.dao;

import java.util.ArrayList;

import com.arun.bean.EmployeeBean;

public interface EmployeeDAO {

	public int insertEmployee(EmployeeBean bean)throws Exception;
	
	public int updateEmployee(EmployeeBean bean)throws Exception;
	
	public int deleteEmployee(int employee_id)throws Exception;
	
	public ArrayList<EmployeeBean> getAllEmployee()throws Exception;
	
	public EmployeeBean getSingleEmployee(int employee_id)throws Exception;
	
	public boolean checkAvialableOfEmployeeId(int employee_id)throws Exception;
}
