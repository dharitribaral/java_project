package com.arun.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.arun.bean.EmployeeBean;
import com.arun.util.DBUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	//delcare all database variable
	private Connection con=null;
	private PreparedStatement ps=null;
	private ResultSet rs=null;
	
	//declare all query here
	private static final String INSERT_EMPLOYEE="insert into employee(employee_id,employee_name,employee_address,employee_sal,deptno) values(?,?,?,?,?)";
	
	private static final String UPDATE_EMPLOYEE="update employee set employee_name=?,employee_address=?,employee_sal=?,deptno=? where employee_id=?";
	
	private static final String GET_ALL_EMPLOYEE="select * from employee";
	
	private static final String DELETE_EMPLOYEE="delete from employee where employee_id=?";
	
	private static final String GET_SINGLE_EMPLOYEE_DETAIL="select * from employee where employee_id=?";
	
	private static final String CHECK_EMPLOYEE_ID="select employee_id from employee where employee_id=?";
	
	public EmployeeDAOImpl() {
		con=DBUtil.getConnection();
	}
	
	@Override
	public int insertEmployee(EmployeeBean bean) throws Exception {
		//this method for insert of the employee record to the database
		ps=con.prepareStatement(INSERT_EMPLOYEE);
		ps.setInt(1, bean.getEmployee_id());
		ps.setString(2, bean.getEmployee_name());
		ps.setString(3, bean.getEmployee_address());
		ps.setString(4, bean.getEmployee_sal());
		ps.setInt(5, bean.getDeptno());
		int count=ps.executeUpdate();
		ps.close();
		ps=null;
		return count;
	}

	@Override
	public int updateEmployee(EmployeeBean bean) throws Exception {
		//this method is identified for update employee record
		ps=con.prepareStatement(UPDATE_EMPLOYEE);
		ps.setString(1, bean.getEmployee_name());
		ps.setString(2, bean.getEmployee_address());
		ps.setString(3, bean.getEmployee_sal());
		ps.setInt(4, bean.getDeptno());
		ps.setInt(5, bean.getEmployee_id());
		int count=ps.executeUpdate();
		ps.close();
		ps=null;
		return count;
	}

	@Override
	public int deleteEmployee(int employee_id) throws Exception {
		ps=con.prepareStatement(DELETE_EMPLOYEE);
		ps.setInt(1, employee_id);
		int count=ps.executeUpdate();
		ps.close();
		ps=null;
		return count;
	}

	@Override
	public ArrayList<EmployeeBean> getAllEmployee() throws Exception {
		ps=con.prepareStatement(GET_ALL_EMPLOYEE);
		rs=ps.executeQuery();
		//create list object to hold all data of employee table
		ArrayList<EmployeeBean> employee_list=new ArrayList<EmployeeBean>();
		while(rs.next()){
			//create EmployeeBean object
			EmployeeBean bean=new EmployeeBean();
			bean.setEmployee_id(rs.getInt("employee_id"));
			bean.setEmployee_name(rs.getString("employee_name"));
			bean.setEmployee_address(rs.getString("employee_address"));
			bean.setEmployee_sal(rs.getString("employee_sal"));
			bean.setDeptno(rs.getInt("deptno"));
			//set bean object to list object
			employee_list.add(bean);
		}
		rs.close();
		ps.close();
		rs=null;
		ps=null;
		return employee_list;
	}

	@Override
	public EmployeeBean getSingleEmployee(int employee_id) throws Exception {
		//this methd is used for getting perticular employee detail using employee id
		ps=con.prepareStatement(GET_SINGLE_EMPLOYEE_DETAIL,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		ps.setInt(1, employee_id);
		rs=ps.executeQuery();
		EmployeeBean bean=null;
		if(rs.next()){
			bean=new EmployeeBean();
			bean.setEmployee_id(rs.getInt("employee_id"));
			bean.setEmployee_name(rs.getString("employee_name"));
			bean.setEmployee_address(rs.getString("employee_address"));
			bean.setEmployee_sal(rs.getString("employee_sal"));
			bean.setDeptno(rs.getInt("deptno"));
		}
		rs.close();
		ps.close();
		rs=null;
		ps=null;
		return bean;
	}

	@Override
	public boolean checkAvialableOfEmployeeId(int employee_id) throws Exception {
		ps=con.prepareStatement(CHECK_EMPLOYEE_ID);
		ps.setInt(1, employee_id);
		rs=ps.executeQuery();
		boolean isAvailable=false;
		if(rs.next()){
			isAvailable=true;
		}
		rs.close();
		ps.close();
		rs=null;
		ps=null;
		return isAvailable;
	}

	
	
	
}
