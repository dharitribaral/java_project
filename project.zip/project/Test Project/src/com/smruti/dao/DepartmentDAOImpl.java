package com.arun.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.arun.bean.DepartmentBean;
import com.arun.util.DBUtil;



public class DepartmentDAOImpl implements DepartmentDAO{
	
	//delcare all database varialbe
	private Connection con=null;
	private PreparedStatement ps=null;
	private ResultSet rs=null;
	
	//declare all query here
	private static final String INSERT_QUERY="insert into department(deptno,deptname,location) values(?,?,?)";
	
	private static final String DELETE_QUERY="delete from department where deptno=?";
	
	private static final String UPDATE_QUERY="update department set deptname=?,location=? where deptno=?";
	
	private static final String SELECT_ALL_DEPT="select * from department";
	
	private static final String SELECT_SINGLE_DEPT="select * from department where deptno=?";
	
	public DepartmentDAOImpl() {
		con=DBUtil.getConnection();
	}
	
	@Override
	public int insertDepartment(DepartmentBean bean) throws Exception {
		//this method is identifies insert department to database
		ps=con.prepareStatement(INSERT_QUERY);
		ps.setInt(1, bean.getDeptno());
		ps.setString(2, bean.getDeptname());
		ps.setString(3, bean.getLocation());
		int count=ps.executeUpdate();
		ps.close();
		ps=null;
		return count;
	}

	@Override
	public int updateDepartment(DepartmentBean bean) throws Exception {
		//this method is identifies update department to database
		ps=con.prepareStatement(UPDATE_QUERY);
		ps.setInt(3, bean.getDeptno());
		ps.setString(1, bean.getDeptname());
		ps.setString(2, bean.getLocation());
		int count=ps.executeUpdate();
		ps.close();
		ps=null;
		return count;
	}

	@Override
	public int deleteDepartment(int deptno) throws Exception {
		ps=con.prepareStatement(DELETE_QUERY);
		ps.setInt(1,deptno);
		int count=ps.executeUpdate();
		ps.close();
		ps=null;
		return count;
	}

	@Override
	public ArrayList<DepartmentBean> getAllDepartment() throws Exception {
		//this method identifies to get all deprt
		ps=con.prepareStatement(SELECT_ALL_DEPT);
		rs=ps.executeQuery();
		//create list object to hold department object
		ArrayList<DepartmentBean> dept_list=new ArrayList<DepartmentBean>();
		while(rs.next()){
			//create departmentbean object
			DepartmentBean bean=new DepartmentBean();
			bean.setDeptno(rs.getInt("deptno"));
			bean.setDeptname(rs.getString("deptname"));
			bean.setLocation(rs.getString("location"));
			dept_list.add(bean);
		}
		return dept_list;
	}

	@Override
	public DepartmentBean getSingleDepartment(int deptno) throws Exception {
		//this method identifies to get all deprt
		ps=con.prepareStatement(SELECT_SINGLE_DEPT);
		ps.setInt(1, deptno);
		rs=ps.executeQuery();
		DepartmentBean bean=null;
		if(rs.next()){
			bean=new DepartmentBean();
			bean.setDeptno(rs.getInt("deptno"));
			bean.setDeptname(rs.getString("deptname"));
			bean.setLocation(rs.getString("location"));
		}
		rs.close();
		ps.close();
		rs=null;
		ps=null;
		return bean;
	}

	
	
}
