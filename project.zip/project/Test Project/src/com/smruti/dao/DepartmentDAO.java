package com.arun.dao;

import java.util.ArrayList;

import com.arun.bean.DepartmentBean;

public interface DepartmentDAO {
	
	public int insertDepartment(DepartmentBean bean)throws Exception;
	
	public int updateDepartment(DepartmentBean bean)throws Exception;
	
	public int deleteDepartment(int deptno)throws Exception;
	
	public ArrayList<DepartmentBean> getAllDepartment()throws Exception;
	
	public DepartmentBean getSingleDepartment(int deptno)throws Exception;
}
